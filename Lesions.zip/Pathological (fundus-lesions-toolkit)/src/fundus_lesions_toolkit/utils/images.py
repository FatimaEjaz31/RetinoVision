# import cv2


# def open_image(image_path):
#     img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
#     return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
import cv2
import numpy as np

def autocrop_fundus(image):
    # Assuming the function crops out the region of interest (ROI) from the fundus image.
    # This is a simplified version for demonstration purposes.
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    _, thresholded = cv2.threshold(gray, 10, 255, cv2.THRESH_BINARY)
    
    # Find contours to detect the region of interest
    contours, _ = cv2.findContours(thresholded, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if contours:
        # Get the bounding box of the largest contour (assuming the largest contour is the ROI)
        x, y, w, h = cv2.boundingRect(contours[0])
        roi = (x, y, w, h)
        # Apply margins (simplified here)
        margins = (y, image.shape[0] - (y + h), x, image.shape[1] - (x + w))
        cropped_image = image[y:y+h, x:x+w]
        return cropped_image, roi, margins
    else:
        return image, None, (0, 0, 0, 0)

def open_image(image_path):
    # Open image using OpenCV and convert to RGB format
    img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
